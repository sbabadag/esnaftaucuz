import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import SplashScreen from './components/screens/SplashScreen';
import OnboardingScreen from './components/screens/OnboardingScreen';
import LocationPermissionScreen from './components/screens/LocationPermissionScreen';
import LoginScreen from './components/screens/LoginScreen';
import MainApp from './components/screens/MainApp';

function App() {
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState(false);
  const [hasLocationPermission, setHasLocationPermission] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background">
        <Routes>
          <Route path="/" element={<SplashScreen />} />
          <Route 
            path="/onboarding" 
            element={<OnboardingScreen onComplete={() => setHasSeenOnboarding(true)} />} 
          />
          <Route 
            path="/location" 
            element={<LocationPermissionScreen onAllow={() => setHasLocationPermission(true)} />} 
          />
          <Route 
            path="/login" 
            element={<LoginScreen onLogin={() => setIsAuthenticated(true)} />} 
          />
          <Route path="/app/*" element={<MainApp />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <Toaster />
      </div>
    </BrowserRouter>
  );
}

export default App;
