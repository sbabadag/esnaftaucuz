import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, MapPin, Clock, CheckCircle2, ThumbsUp, ThumbsDown, Flag } from 'lucide-react';
import { Button } from '../../ui/button';
import { Badge } from '../../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';

const mockPriceData = [
  { id: 1, price: '12,00', location: 'Yazır Pazarı', time: '2 saat önce', verified: true, distance: '1.2 km' },
  { id: 2, price: '13,50', location: 'Akabe Manav', time: '4 saat önce', verified: true, distance: '800m' },
  { id: 3, price: '15,00', location: 'Carrefour', time: '1 gün önce', verified: false, distance: '2.1 km', isOld: true },
];

export default function ProductDetailScreen() {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl">Domates</h1>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-white p-6 border-b border-gray-200">
        <div className="text-sm text-gray-600 mb-1">Ortalama fiyat</div>
        <div className="text-3xl text-gray-900 mb-3">14,20 TL</div>
        <div className="text-sm text-green-600">Bugün en ucuz: 12,00 TL</div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2>Mevcut Fiyatlar</h2>
          <Select defaultValue="cheap">
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cheap">En ucuz</SelectItem>
              <SelectItem value="new">En yeni</SelectItem>
              <SelectItem value="verified">En güvenilir</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Price List */}
      <div className="p-4 space-y-3">
        {mockPriceData.map((item) => (
          <div key={item.id} className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-2xl text-green-600">{item.price} TL <span className="text-sm text-gray-500">/ kg</span></div>
                <div className="text-sm text-gray-600 mt-1">{item.location}</div>
              </div>
              {item.isOld ? (
                <Badge variant="secondary">Eski fiyat</Badge>
              ) : (
                <Badge className="bg-green-600">BUGÜN</Badge>
              )}
            </div>

            <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {item.distance}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {item.time}
              </span>
              {item.verified && (
                <span className="flex items-center gap-1 text-green-600">
                  <CheckCircle2 className="w-4 h-4" />
                  Doğrulanmış
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                <ThumbsUp className="w-4 h-4 mr-2" />
                Doğrula
              </Button>
              <Button variant="outline" size="sm">
                <Flag className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
