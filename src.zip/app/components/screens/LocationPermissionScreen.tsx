import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { MapPin } from 'lucide-react';
import { Button } from '../ui/button';
import { toast } from 'sonner';

export default function LocationPermissionScreen({ onAllow }: { onAllow: () => void }) {
  const navigate = useNavigate();

  const handleAllow = () => {
    // Simulate location permission request
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        () => {
          toast.success('Konum izni verildi');
          onAllow();
          navigate('/login');
        },
        () => {
          toast.error('Konum izni reddedildi');
          navigate('/login');
        }
      );
    } else {
      toast.info('Konum servisi desteklenmiyor');
      navigate('/login');
    }
  };

  const handleSkip = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col p-6">
      <div className="flex-1 flex flex-col items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
          className="bg-green-100 rounded-full p-16 mb-8"
        >
          <MapPin className="w-24 h-24 text-green-600" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl text-center mb-4 text-gray-900"
        >
          Konumunu kullanalım mı?
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center text-lg text-gray-600 max-w-md"
        >
          Sana en yakın ve güncel fiyatları gösterebilmemiz için konumuna ihtiyacımız var.
        </motion.p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="space-y-3"
      >
        <Button
          onClick={handleAllow}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-lg"
        >
          Konumu Aç
        </Button>

        <Button
          onClick={handleSkip}
          variant="ghost"
          className="w-full text-gray-600 hover:text-gray-900 py-6 text-lg"
        >
          Şimdilik Geç
        </Button>
      </motion.div>
    </div>
  );
}
