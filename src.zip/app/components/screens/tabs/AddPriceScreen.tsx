import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Camera, Image as ImageIcon, Check } from 'lucide-react';
import { Button } from '../../ui/button';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { RadioGroup, RadioGroupItem } from '../../ui/radio-group';
import { toast } from 'sonner';

const steps = ['product', 'price', 'location', 'photo', 'confirm'];

const mockProducts = ['Domates', 'Patates', 'Tavuk', 'Süt', 'Ekmek', 'Yumurta'];
const mockLocations = ['Yazır Pazarı', 'Akabe Manav', 'Carrefour Selçuklu', 'Migros Selçuklu'];

export default function AddPriceScreen() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    product: '',
    price: '',
    unit: 'kg',
    location: '',
    photo: null as File | null,
  });

  const stepName = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Submit
      toast.success('🎉 Teşekkürler!', {
        description: 'Paylaşımın yayına alındı. +10 katkı puanı kazandın',
      });
      navigate('/app/explore');
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      navigate('/app/explore');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={handleBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <div className="flex gap-1">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-1 flex-1 rounded-full ${
                    index <= currentStep ? 'bg-green-600' : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {stepName === 'product' && (
          <div>
            <h2 className="text-2xl mb-2">Ürün seç</h2>
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Ürün ara"
                className="pl-10"
                value={formData.product}
                onChange={(e) => setFormData({ ...formData, product: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {mockProducts.map((product) => (
                <Button
                  key={product}
                  variant={formData.product === product ? 'default' : 'outline'}
                  className={formData.product === product ? 'bg-green-600 hover:bg-green-700' : ''}
                  onClick={() => setFormData({ ...formData, product })}
                >
                  {product}
                </Button>
              ))}
            </div>
          </div>
        )}

        {stepName === 'price' && (
          <div>
            <h2 className="text-2xl mb-4">Fiyat bilgisi</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="price">Fiyat (TL)</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="0.00"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="text-2xl"
                />
              </div>
              <div>
                <Label>Birim</Label>
                <RadioGroup value={formData.unit} onValueChange={(value) => setFormData({ ...formData, unit: value })}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="kg" id="kg" />
                    <Label htmlFor="kg">kg</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="adet" id="adet" />
                    <Label htmlFor="adet">adet</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="lt" id="lt" />
                    <Label htmlFor="lt">lt</Label>
                  </div>
                </RadioGroup>
              </div>
              <p className="text-sm text-gray-500">Lütfen gördüğün fiyatı aynen gir.</p>
            </div>
          </div>
        )}

        {stepName === 'location' && (
          <div>
            <h2 className="text-2xl mb-4">Nereden aldın?</h2>
            <div className="space-y-2 mb-4">
              {mockLocations.map((location) => (
                <Button
                  key={location}
                  variant={formData.location === location ? 'default' : 'outline'}
                  className={`w-full justify-start ${formData.location === location ? 'bg-green-600 hover:bg-green-700' : ''}`}
                  onClick={() => setFormData({ ...formData, location })}
                >
                  {location}
                </Button>
              ))}
            </div>
            <Button variant="outline" className="w-full">
              Haritadan Seç
            </Button>
          </div>
        )}

        {stepName === 'photo' && (
          <div>
            <h2 className="text-2xl mb-2">Fotoğraf ekle</h2>
            <p className="text-gray-500 mb-6">Etiket veya tezgâh fotoğrafı güveni artırır.</p>
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant="outline"
                className="h-32 flex-col gap-2"
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/*';
                  input.capture = 'environment';
                  input.click();
                }}
              >
                <Camera className="w-8 h-8" />
                <span>Kamera</span>
              </Button>
              <Button
                variant="outline"
                className="h-32 flex-col gap-2"
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/*';
                  input.click();
                }}
              >
                <ImageIcon className="w-8 h-8" />
                <span>Galeri</span>
              </Button>
            </div>
          </div>
        )}

        {stepName === 'confirm' && (
          <div>
            <h2 className="text-2xl mb-2">Bilgileri kontrol et</h2>
            <p className="text-gray-500 mb-6">Yanlış fiyat girilmesi kullanıcıları yanıltır.</p>
            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Ürün:</span>
                <span>{formData.product}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Fiyat:</span>
                <span className="text-xl text-green-600">{formData.price} TL / {formData.unit}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Yer:</span>
                <span>{formData.location}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200">
        <Button
          onClick={handleNext}
          disabled={
            (stepName === 'product' && !formData.product) ||
            (stepName === 'price' && !formData.price) ||
            (stepName === 'location' && !formData.location)
          }
          className="w-full bg-green-600 hover:bg-green-700 py-6"
        >
          {stepName === 'confirm' ? (
            <>
              <Check className="w-5 h-5 mr-2" />
              Fiyatı Paylaş
            </>
          ) : (
            'Devam'
          )}
        </Button>
      </div>
    </div>
  );
}
