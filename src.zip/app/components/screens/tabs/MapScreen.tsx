import { MapPin } from 'lucide-react';
import { Badge } from '../../ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../../ui/sheet';
import { useState } from 'react';

const mockMapPrices = [
  { id: 1, product: 'Domates', price: '12 TL', lat: 37.8667, lng: 32.4833, distance: '500m' },
  { id: 2, product: 'Patates', price: '8,50 TL', lat: 37.8700, lng: 32.4900, distance: '800m' },
];

export default function MapScreen() {
  const [selectedPrice, setSelectedPrice] = useState<typeof mockMapPrices[0] | null>(null);

  return (
    <div className="min-h-screen bg-gray-200 relative">
      {/* Map Header */}
      <div className="absolute top-0 left-0 right-0 bg-white/95 backdrop-blur-sm p-4 z-10 border-b border-gray-200">
        <h1 className="text-center">Haritada fiyatlar</h1>
      </div>

      {/* Mock Map */}
      <div className="h-screen w-full bg-gradient-to-br from-green-100 to-blue-100 flex items-center justify-center relative">
        <div className="text-center text-gray-500">
          <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p>Harita görünümü</p>
          <p className="text-sm mt-2">Gerçek harita entegrasyonu için harita API'si gerekli</p>
        </div>

        {/* Mock pins */}
        {mockMapPrices.map((item, index) => (
          <div
            key={item.id}
            onClick={() => setSelectedPrice(item)}
            className="absolute cursor-pointer"
            style={{
              left: `${30 + index * 20}%`,
              top: `${40 + index * 10}%`,
            }}
          >
            <div className="relative">
              <MapPin className="w-10 h-10 text-red-500 fill-red-500/20 animate-bounce" />
              <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded shadow-lg text-sm whitespace-nowrap">
                {item.product} – {item.price}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Sheet */}
      <Sheet open={!!selectedPrice} onOpenChange={() => setSelectedPrice(null)}>
        <SheetContent side="bottom" className="h-[40vh]">
          <SheetHeader>
            <SheetTitle>Bu bölgede bulunan fiyatlar</SheetTitle>
          </SheetHeader>
          <div className="py-4 space-y-3">
            {mockMapPrices.map((item) => (
              <div key={item.id} className="border border-gray-200 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h3>{item.product}</h3>
                    <p className="text-xl text-green-600">{item.price}</p>
                  </div>
                  <Badge variant="secondary">📍 {item.distance}</Badge>
                </div>
              </div>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
