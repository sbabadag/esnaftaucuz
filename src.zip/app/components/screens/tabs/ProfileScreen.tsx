import { useNavigate } from 'react-router-dom';
import { Settings, Heart, Award, Share2, LogOut, ChevronRight } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '../../ui/avatar';
import { Badge } from '../../ui/badge';
import { Button } from '../../ui/button';

export default function ProfileScreen() {
  const navigate = useNavigate();

  const menuItems = [
    { icon: Share2, label: 'Katkılarım', onClick: () => {} },
    { icon: Heart, label: 'Favorilerim', onClick: () => {} },
    { icon: Award, label: 'Rozetler', onClick: () => {} },
    { icon: Settings, label: 'Ayarlar', onClick: () => navigate('/app/settings') },
    { icon: Share2, label: 'Destek & Geri Bildirim', onClick: () => {} },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white p-6 border-b border-gray-200">
        <div className="flex items-center gap-4 mb-6">
          <Avatar className="w-20 h-20">
            <AvatarImage src="" />
            <AvatarFallback className="bg-green-600 text-white text-2xl">KK</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h2 className="text-2xl">Konya Kullanıcısı</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-gray-600">Seviye:</span>
              <Badge variant="secondary">Mahalleli 🏅</Badge>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl text-green-600">12</div>
            <div className="text-sm text-gray-600">Paylaşım</div>
          </div>
          <div className="text-center">
            <div className="text-2xl text-green-600">8</div>
            <div className="text-sm text-gray-600">Doğrulama</div>
          </div>
          <div className="text-center">
            <div className="text-2xl text-green-600">240</div>
            <div className="text-sm text-gray-600">Puan</div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="p-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.label}
            onClick={item.onClick}
            className="w-full bg-white rounded-lg p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <item.icon className="w-5 h-5 text-gray-600" />
              <span>{item.label}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        ))}

        <button
          onClick={() => navigate('/')}
          className="w-full bg-white rounded-lg p-4 flex items-center gap-3 hover:bg-red-50 transition-colors text-red-600"
        >
          <LogOut className="w-5 h-5" />
          <span>Çıkış Yap</span>
        </button>
      </div>
    </div>
  );
}
