import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Bell, Filter, MapPin, Clock, CheckCircle2 } from 'lucide-react';
import { Button } from '../../ui/button';
import { Input } from '../../ui/input';
import { Badge } from '../../ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '../../ui/sheet';
import { Checkbox } from '../../ui/checkbox';
import { Label } from '../../ui/label';

const trendProducts = ['Domates', 'Patates', 'Tavuk', 'Ayçiçek Yağı', 'Ekmek', 'Süt'];

const mockPrices = [
  {
    id: 1,
    product: 'Domates',
    price: '12,00',
    unit: 'kg',
    location: 'Yazır Pazarı',
    distance: '1.2',
    time: '2 saat önce',
    verified: true,
    isToday: true,
  },
  {
    id: 2,
    product: 'Patates',
    price: '8,50',
    unit: 'kg',
    location: 'Akabe Manav',
    distance: '800m',
    time: '4 saat önce',
    verified: true,
    isToday: true,
  },
  {
    id: 3,
    product: 'Tavuk Göğüs',
    price: '85,00',
    unit: 'kg',
    location: 'Konya Et Pazarı',
    distance: '2.1 km',
    time: '30 dakika önce',
    verified: false,
    isToday: true,
  },
  {
    id: 4,
    product: 'Ayçiçek Yağı',
    price: '75,00',
    unit: 'lt',
    location: 'Carrefour Selçuklu',
    distance: '1.5 km',
    time: '1 saat önce',
    verified: true,
    isToday: true,
  },
];

export default function ExploreScreen() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    pazar: false,
    manav: false,
    market: false,
    kasap: false,
    todayOnly: false,
    withPhoto: false,
    verified: false,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="px-4 pt-4 pb-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin className="w-4 h-4" />
              <span>Konya / Selçuklu ▾</span>
            </div>
            <button
              onClick={() => navigate('/app/notifications')}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <Bell className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Ürün veya yer ara"
                className="pl-10"
              />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <Filter className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>Filtrele</SheetTitle>
                </SheetHeader>
                <div className="py-6 space-y-6">
                  <div>
                    <h3 className="mb-3">Yer Türü</h3>
                    <div className="space-y-2">
                      {['pazar', 'manav', 'market', 'kasap'].map((type) => (
                        <div key={type} className="flex items-center space-x-2">
                          <Checkbox
                            id={type}
                            checked={filters[type as keyof typeof filters] as boolean}
                            onCheckedChange={(checked) => setFilters({ ...filters, [type]: checked })}
                          />
                          <Label htmlFor={type} className="capitalize">{type}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="mb-3">Zaman</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="todayOnly"
                        checked={filters.todayOnly}
                        onCheckedChange={(checked) => setFilters({ ...filters, todayOnly: !!checked })}
                      />
                      <Label htmlFor="todayOnly">Sadece bugün girilenler</Label>
                    </div>
                  </div>

                  <div>
                    <h3 className="mb-3">Güven</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="withPhoto"
                          checked={filters.withPhoto}
                          onCheckedChange={(checked) => setFilters({ ...filters, withPhoto: !!checked })}
                        />
                        <Label htmlFor="withPhoto">Fotoğraflı</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="verified"
                          checked={filters.verified}
                          onCheckedChange={(checked) => setFilters({ ...filters, verified: !!checked })}
                        />
                        <Label htmlFor="verified">Doğrulanmış</Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button className="flex-1 bg-green-600 hover:bg-green-700">
                      Filtreyi Uygula
                    </Button>
                    <Button variant="outline" className="flex-1">
                      Temizle
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {/* Trend Products */}
        <section>
          <h2 className="text-lg mb-3 text-gray-900">Bugün En Çok Bakılanlar</h2>
          <div className="flex flex-wrap gap-2">
            {trendProducts.map((product) => (
              <Badge
                key={product}
                variant="secondary"
                className="px-4 py-2 bg-white border border-gray-200 hover:border-green-600 hover:bg-green-50 cursor-pointer"
                onClick={() => navigate(`/app/product/${product}`)}
              >
                {product}
              </Badge>
            ))}
          </div>
        </section>

        {/* Nearby Cheap */}
        <section>
          <h2 className="text-lg mb-3 text-gray-900">Sana Yakın En Ucuz</h2>
          <div className="space-y-3">
            {mockPrices.slice(0, 2).map((item) => (
              <div
                key={item.id}
                onClick={() => navigate(`/app/product/${item.id}`)}
                className="bg-white rounded-lg p-4 border border-gray-200 hover:border-green-600 cursor-pointer transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg text-gray-900">{item.product}</h3>
                    <p className="text-2xl text-green-600">{item.price} TL <span className="text-sm text-gray-500">/ {item.unit}</span></p>
                  </div>
                  {item.isToday && (
                    <Badge className="bg-green-600">BUGÜN</Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {item.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {item.time}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                  <span>📍 {item.distance} km</span>
                  {item.verified && (
                    <span className="flex items-center gap-1 text-green-600">
                      <CheckCircle2 className="w-4 h-4" />
                      Doğrulanmış
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Recent Prices */}
        <section>
          <h2 className="text-lg mb-3 text-gray-900">Son Girilen Fiyatlar</h2>
          <div className="space-y-3">
            {mockPrices.map((item) => (
              <div
                key={item.id}
                onClick={() => navigate(`/app/product/${item.id}`)}
                className="bg-white rounded-lg p-4 border border-gray-200 hover:border-green-600 cursor-pointer transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg text-gray-900">{item.product}</h3>
                    <p className="text-2xl text-green-600">{item.price} TL <span className="text-sm text-gray-500">/ {item.unit}</span></p>
                  </div>
                  {item.isToday && (
                    <Badge className="bg-green-600">BUGÜN</Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-2">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {item.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {item.time}
                  </span>
                </div>
                {item.verified && (
                  <div className="flex items-center gap-1 text-sm text-green-600">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Doğrulanmış</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
